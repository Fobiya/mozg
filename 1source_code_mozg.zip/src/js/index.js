//import $ from 'jquery';

import './common.js';

import './send.js';


//import './jquery.fancybox.min.js';
//
//import './jquery-3.2.1.min.js';