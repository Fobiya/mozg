
import $ from 'jquery';

 
//import './js/jquery-3.2.1.min.js';

//import './js/jquery.fancybox.min.js';

import '@fancyapps/fancybox';

import 'slick-carousel';

import './js/';


//import 'fancybox';


import './scss/main.scss';
// CSS (example)
//import './css/main.css';

